====================================================================
Code Readme
Tkinter GUI Application Development Projects
Section 1: List of Programs
====================================================================

1.01  : Your first GUI application - the top level window
1.02  : Adding some widgets
1.03  : A demonstration of all core tkinter widgets
1.04  : A demonstration of some of pack() options
1.05  : Where to use pack() options
1.06  : Simple example of grid Geometry Manager
1.07  : A demonstration of common grid() options
1.08  : A demonstration of common place() options
1.09  : A demonstration of event binding with the bind() method
1.10  : A demonstration of all Widget Binding
1.11  : A demonstration of tkinter Variable Class IntVar, StringVar & BooleanVar
1.12  : A demonstration of tkinter styling


File Extension: .py
Requires Python 3.4.x Installation to run.
@author: Bhaskar Chauhdary
