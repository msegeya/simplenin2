"""
Code illustration: 4.03
@ Tkinter GUI Application Development Blueprints
"""
class ChessError(Exception): pass
