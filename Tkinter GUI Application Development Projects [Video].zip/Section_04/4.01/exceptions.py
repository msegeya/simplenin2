
class ChessError(Exception): pass
