class ChessError(Exception): pass
