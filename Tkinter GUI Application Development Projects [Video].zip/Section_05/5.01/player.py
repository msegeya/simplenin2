 

import pyglet

class Player:
    
    def __init__(self):
        pass        
   
    
