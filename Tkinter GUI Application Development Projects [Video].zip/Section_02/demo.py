import tkinter.filedialog

file_object = tkinter.filedialog.askopenfile()
